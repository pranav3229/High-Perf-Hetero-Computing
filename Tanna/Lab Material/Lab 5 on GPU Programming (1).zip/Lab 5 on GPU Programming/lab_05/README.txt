The directory contains two makefiles:
	- Makefile : use if you have a CUDA-capable GPU
	- Makefile_ocelot : use if you will run the program with the assistance of Ocelot

After compilation, run the program by passing as a command-line parameter the filename of a PGM image. Example:

	./histogram mountains.pgm

