Use the following command to run hillis code:
```
make codefile=hillis.c count=8 threads=8
```

For blelloch code:
```
make codefile=blelloch.c count=8 threads=8
```
