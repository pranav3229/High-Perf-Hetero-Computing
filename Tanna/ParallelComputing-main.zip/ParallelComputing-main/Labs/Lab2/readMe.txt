Aakash - 2018B4A70887P

The result could not be reported for n = 10, 100 and 1000 because number of threads required for log barrier for code given in book should be a power of two.

The result for n = 8 is:
Linear barrier	: 0.000715 sec
Log barrier	: 0.000767 sec

The result for n = 16 is:
Linear barrier	: 0.001494 sec
Log barrier	: 0.001295 sec

The result for n = 128 is:
Linear barrier	: 0.012320 sec
Log barrier	: 0.009359 sec

The result for n = 1024 is:
Linear barrier	: 0.174230 sec
Log barrier	: 0.096934 sec
