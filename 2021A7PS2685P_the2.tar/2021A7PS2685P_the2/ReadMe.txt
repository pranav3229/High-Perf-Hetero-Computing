Time taken by linear barrier with 10 threads: 574 microseconds
Time taken by tree barrier with 10 threads: 395 microseconds
Time taken by linear barrier with 100 threads: 7068 microseconds
Time taken by tree barrier with 100 threads: 3192 microseconds
Time taken by linear barrier with 1000 threads: 57913 microseconds
Time taken by tree barrier with 1000 threads: 33308 microseconds
